import os
import sys
import json
import base64
import cv2
import numpy as np
import tensorflow as tf
from tensorflow_examples.models.pix2pix import pix2pix
# model_path - путь к вашей модели (с именем и расширением файла, относительно скрипта в вашем архиве проекта)
# dataset_path - путь к папке с тестовым датасетом.
# Он состоит из n фотографий c расширением .jpg (гарантируется, что будет только это расширение)
# output_path - путь к файлу, в который будут сохраняться результаты (с именем и расширением файла)
dataset_path = "train_dataset\cv_open_dataset\open_img"
output_path = r"docerfile\\output"


base_model = tf.keras.applications.MobileNetV2(input_shape=[224, 224, 3], include_top=False)

layer_names = [
    'block_1_expand_relu',   # 64x64
    'block_3_expand_relu',   # 32x32
    'block_6_expand_relu',   # 16x16
    'block_13_expand_relu',  # 8x8
    'block_16_project',      # 4x4
]
base_model_outputs = [base_model.get_layer(name).output for name in layer_names]

down_stack = tf.keras.Model(inputs=base_model.input, outputs=base_model_outputs)

down_stack.trainable = False

up_stack = [
    pix2pix.upsample(512, 3),  # 4x4 -> 8x8
    pix2pix.upsample(256, 3),  # 8x8 -> 16x16
    pix2pix.upsample(128, 3),  # 16x16 -> 32x32
    pix2pix.upsample(64, 3),   # 32x32 -> 64x64
]

def unet_model(output_channels:int):
  inputs = tf.keras.layers.Input(shape=[224, 224, 3])
  skips = down_stack(inputs)
  x = skips[-1]
  skips = reversed(skips[:-1])

  for up, skip in zip(up_stack, skips):
    x = up(x)
    concat = tf.keras.layers.Concatenate()
    x = concat([x, skip])


  last = tf.keras.layers.Conv2DTranspose(
      filters=output_channels, kernel_size=3, strides=2,
      padding='same', activation='sigmoid')

  x = last(x)

  return tf.keras.Model(inputs=inputs, outputs=x)

model = unet_model(output_channels=1)
model.load_weights(r'docerfile\\model\\checkpoin.weights.h5')

def normalize(image, mask):
    image = tf.cast(image, tf.float32) / 255
    mask = mask / 113
    return image, mask

# Пример функции инференса модели
def infer_image(model, image_path):
    # Загрузка изображения
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    image_resized = cv2.resize(image, (224,224))
    image_resized = image_resized / 255.0
    image_input = np.expand_dims(image_resized, axis=0)

    predict = model.predict(image_input)
    return predict


# TODO Ваш проект будет перенесен целиком, укажите корректны относительный путь до модели!!!
# TODO Помните, что доступа к интернету не будет и нельзя будет скачать веса модели откуда-то с внешнего ресурса!

# # Тут показан пример с использованием модели, полученной из бейзлайна
# example_model = model(model_path)
# example_model.to('cpu')


def create_mask(image_path, results):
    mask = results[0]  # Например, если модель возвращает маску
    print(f"Mask shape: {mask.shape}")
    image = cv2.imread(image_path)
    height, width = image.shape[:2]
    mask_resized = cv2.resize(mask, (width, height), interpolation=cv2.INTER_NEAREST)
    mask_bin = (mask_resized > 0.5).astype(np.uint8) * 255  # Бинаризация
    return mask_bin


# Ваша задача - произвести инференс и сохранить маски НЕ в отдельные файлы, а в один файл submit.
# Для этого мы сначала будем накапливать результаты в словаре, а затем сохраним их в JSON.
results_dict = {}

for image_name in os.listdir(dataset_path):
    if image_name.lower().endswith(".jpg"):
        predictions = infer_image(model, os.path.join(dataset_path, image_name))
        mask = create_mask(os.path.join(dataset_path, image_name), predictions)
        
        # Кодируем маску в PNG в память
        _, encoded_img = cv2.imencode(".png", mask)
        if not _:
            print("Error encoding image")  # Для отладки
        # Кодируем в base64, чтобы поместить в JSON
        encoded_str = base64.b64encode(encoded_img).decode('utf-8')
        results_dict[image_name] = encoded_str
# Сохраняем результаты в один файл "submit" (формат JSON)
submit_path = os.path.join(output_path, "submit.json")
with open(submit_path, "w", encoding="utf-8") as f:
    json.dump(results_dict, f, ensure_ascii=False)
